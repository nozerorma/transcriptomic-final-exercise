# Informe de caso

## Trabajo final del módulo de transcriptómica 2022/23

### Alumno: Miguel Ramón Alonso

## INTRODUCCIÓN

El objetivo de este trabajo es que el alumno demuestre los conocimientos obtenidos acerca del análisis de RNA-seq. Para ello deberá **redactar un informe** en el que se expliquen los datos de partida y se extraiga una **conclusión de los resultados**. Así mismo, el alumno debe **detallar el proceso de análisis** indicando el *software* (incluída la versión) empleado, así como los parámetros utilizados en cada uno de los pasos. En caso de que hubiera que eliminar muestras por motivos técnicos o biológicos, el alumno debe indicar y justificar el por qué en cada caso. Se pueden introducir *code chunks* e imágenes para apoyar el informe. De manera alternativa, puede aportarse todo el código en forma de repositorio público. Se han planteado **5 preguntas (10 puntos en total)** para guiar la redacción del informe.

El trabajo consta de dos apartados en los que se utilizarán datos de un experimento en el que disponemos de 24 cultivos primarios de tumores paratiroideos negativos para receptores de estrógenos alfa (ERα). Las muestras, procedentes de 4 pacientes diferentes, se han tratado con dos fármacos diferentes: diarilpropionitrilo (DPN) o 4-hidroxitamoxifeno (OHT) a 24h o 48h. El DPN es un agonista del ERα mientras que el OHT es un inhibidor competitivo de los receptores de estrógenos.

El **primer apartado (3 preguntas)** abarca los pasos de control de calidad y de fuentes de contaminación, *trimming*, alineamiento y cuantificación para obtener cuentas crudas y normalizadas a partir de un **subset de ficheros fastq**. El **segundo apartado (2 preguntas)** parte de la **matriz completa de cuentas crudas** y está enfocado a realizar un control de calidad biológico, detectar los genes diferencialmente expresados entre condiciones y los pathways enriquecidos en cada una de ellas.

#### Apartado 1

El dataset original consta de 27 muestras paired-end depositadas en SRA. Con el fin de poder abordar las cuestiones planteadas a en el primer apartado sólo es necesario descargar 2 muestras (SRR479052 y SRR479054), es decir cuatro ficheros fastq. Además, en este repositorio se proporciona:

- Un fichero fasta con la secuencia de la referencia genómica, en este caso correspondiente al cromosoma 21 humano (ensamblaje GRCh38).
- Un fichero GTF con la anotación génica para los genes del cromosoma 21 (GRCh38.ensembl.109).

Se pide realizar un análisis de dichas muestras similar al realizado en clase, considerando los siguientes puntos:

**Pregunta 1 (1.5 puntos):** Realizar control de calidad de dichas muestras con el programa FastQC, incluir plots más reseñables y comentar cada uno de los apartados. De manera complementaria se podrá realizar un analisis de contaminación con el programa FastQScreen.

**Pregunta 2 (1.5 puntos):** Para poder llevar a cabo el alineamiento de las muestras en vuestros ordenadores será necesario trabajar con archivos reducidos correspondientes al cromosoma 21. Se requiere el indexado de la secuencia de este cromosoma, así como el alineamiento de las muestras a dicha referencia. Para ello se podrá utilizar el alineador HISAT2 utilizado en clase u otros (alineadores o pseudoalineadores). Comentar cada uno de los comandos y parámetros empleados, justificando su uso.

**Pregunta 3 (1.5 puntos):** Una vez generados los archivos alineados se reportarán las estadísticas de alineamiento y se procederá a la cuantificación de la expresión utilizando el archivo GTF correspondiente. Para ello se podrá utilizar HTSeq u otras herramientas de cuantificación. En cualquier caso, detallar y justificar los comandos y parámetros empleados para ello.

#### Apartado 2

En este repositorio se proporcionan todos los inputs del Apartado 2:

- La matriz de cuentas crudas para los 24 cultivos analizados.
- Data frame con los metadatos asociados al experimento.
- GMT para realizar un GSEA.

**Pregunta 4 (3 puntos):** ¿Qué genes se encuentran diferencialmente expresados entre las muestras pertenecientes al grupo tratado con OHT con respecto al control tras 24h? ¿Y en el caso de las muestras tratadas con DPN, también tras 24h? Como parte de la respuesta a esta pregunta, podéis entregar una o más tablas adjuntas donde se incluyan los genes diferencialmente expresados, indicando el criterio o los criterios que habéis seguido para filtrar los resultados, así como cualquier otro gráfico o gráficos que hayáis elaborado durante el análisis.

**Pregunta 5 (2.5 puntos):** Nuestro colaborador ha comparado las muestras tratadas con DPN tras 48h con las muestras control. Nos ha llamado para contarnos que los cambios de expresión tras 48h son mucho más evidentes y nos preguntamos si el DPN produce algún efecto en las primeras 24h. Para contestar esta pregunta, le pedimos que genere un GMT (input) con los genes más expresados en las muestras tratadas tras 48h (DPN_perturbed) y los genes más expresados en la muestra control (DPN_unperturbed). Realiza un análisis con GSEA para determinar el efecto del tratamiento a las 24h. ¿A qué conclusión llegas? Incluid una tabla con los resultados del análisis, destacando las columnas con los valores utilizados para extraer vuestras conclusiones. También incluid los gráficos característicos de este tipo de análisis.

## MÉTODOS

Para dar respuesta  a las diferentes preguntas que propone el ejercicio, se decidió realizar un pipeline interactivo, que permitiese al usuario introducir cualquier muestra SRA, la cual sería descargada, desempaquetada en los correspondientes archivos FASTQ, analizada, preprocesada, alineada y post-procesada utilizando diferentes metodologías.

#### Descarga del genoma `download.sh`

Se utilizó la herramienta de sistema *wget*, integrando un *input control* que confirme la correcta introducción del formato de SRA por parte del usuario (**if [[ "SRAentry" =~ ^[Ss]if [[ "SRAentry" =~ ^[Ss]RR[0-9]{6}RR[0-9]{6} ]]**), y los parámetros específicos de *wget* **-nc (no clobber, evita descargas en duplicado)**, **-P (designa el directorio de descarga)**, y **--content-disposition (mantiene la integridad del formato de descarga, evitando el que por error descargue la el enlace como HTML)**.

```shell
 if [[ "$SRAentry" =~ ^[Ss]RR[0-9]{6}$ ]]; then
                echo "Matched SRA accession $SRAentry"
                (wget -nc -P $sample_dir/SRA --content-disposition https://sra-pub-run-odp.s3.amazonaws.com/sra/$SRAentry/$SRAentry) & spinner
                echo "Finished downloading $SRAentry"
```

Al igual que para el resto de procesos que se realizan a lo largo del pipeline, se añadió un pequeño spinner o reloj para embellecer la espera y para dar al usuario seguridad de que el programa no se ha congelado (ver `& spinner` y `spinner.sh`. )

#### Desempaquetado de ficheros FASTQ `download.sh`

Se utilizó la herramienta fasterq-dump para desempaquetar el fichero SRA en los consecuentes fFASTQ y rFASTQ, introduciendo una comprobación de existencia del fichero. Los parámetros utilizados fueron **-fp** (forzar extracción y mostrar barra de procesamiento).

```shell
if [ "$(ls -A $sample_dir/dumped_fastq/$SRAentry)" ]; then
                        echo -e "Fastq already dumped for $SRAentry, skipping.\n"

                    else
                        (fasterq-dump -fp -O $sample_dir/dumped_fastq/$SRAentry $SRAentry) & spinner $!
```

Una vez descargados, se le pregunta al usuario si desea realizar un control de calidad de los FASTQ brutos. En caso afirmativo se procede al paso de QC; en caso contrario, se procede directamente al menú general.

```shell
read -rp "Would you like to perform a QC analysis (FastQC and FastQScreen)? (Y/n): " performQC

for SRAentry in "${SRAentries[@]}"; do
    for sid in $(find $sample_dir/dumped_fastq/$SRAentry -type f -name '*.fastq'); do
        base_sid=$(basename $sid | cut -d"_" -f1)

        if [ "$(ls -A $sample_dir/dumped_fastq/$base_sid)" ]; then
            case $performQC in
                [Yy]* )
                    bash scripts/qc.sh $sid "out/qc/fastqc" "out/qc/fastq_screen"
                ;;
                [Nn]* )
                    echo -e "\nSkipping QC analysis...\n"
                    break 
                ;;
            esac
        fi
    done
done


# Results visualization
case $performQC in
[Yy]* )
    printf "${GREEN}\nNow, take your time to give a look to the QC analysis.\n${NC}"
    echo "When you are ready, press any key to continue..."
    read -n 1 -s -r -p ""
;;
esac
```

#### OPT 1: Realizar control de calidad de FASTQ brutos `qc.sh`

Para el control de calidad de las muestras, se utilizó la combinación de programas *fastQC* y *fastq-screen*. El script tiene dos posibilidades de uso; por una parte, está pensado para ser utilizado dentro de la ejecución del pipeline `pipeline.sh`, como se ha descrito hasta ahora en la metodología; por otra, y al igual que el resto de herramientas que se describan en adelante, permite un uso independiente con cualquier fichero correspondiente que disponga el usuario, mediante la siguiente porción de código:

```shell
# Comprobation for independent use of script
if [ "$#" -ne 3 ]
then
    printf "${RED}Usage: $1 <fastq_file> $2 <fastqc_out_dir> $3 <fastqscreen_out_dir> ${NC}\n"
    exit 1
fi 
```

En este caso, el programa comprueba la inserción de 3 parámetros junto con la ejecución del código (sucede por defecto con el pipeline general), y en caso contrario, avisa al usuario del uso correcto de la herramienta. El ${RED} hace referencia a una serie de variables declaradas en la cabecera de cada script, indicando diferentes colores que van a ser usados para dar mayor comprehensibilidad al código.

##### FASTQC

Realiza las comprobaciones pertinentes y después ejecuta el programa *fastQC* con los parámetros **-o (directorio de salida del informe generado)** y **2>&1 >/dev/null | tail -n +2 2>&1 log/qc/fastqc.log (redirige la salida de consola a un fichero externo y elimina una línea innecesaria que puede dar lugar a confusión).**

```shell
fastqc -o $fastqc_dir/$cut_sid $sid 2>&1 >/dev/null | tail -n +2 2>&1 log/qc/fastqc.log
```

##### FASTQ-SCREEN

Realiza las comprobaciones pertinentes

```shell
if [ -f $fastqscreen_dir/$cut_sid/${nofastq_sid}_screen.html ]; then
    echo -e "FastQScreen analysis already performed for $nofastq_sid, skipping analysis.\n" 
```

y otorga al usuario la posibilidad de descargar los índices de referencia utilizados por la herramienta para el uso de la misma, añadiendo un aviso para el usuario sobre el peso de los mismos y el tiempo de descarga que requieren

```shell
else
    screen_gen="res/fastq_screen_samples/FastQ_Screen_Genomes"
    if [ ! "$(ls -A $screen_gen)" ]; then
        echo "No reference genomes could be found."
        echo -e "\nWould you like to download genome indexes from database?"
        echo -e "It takes long AND it takes space. Note that if you don't download the references,
you have to manually curate fastqscreen.conf file and point the program to it" 
        read -rp "Continue? (Y/n): " genDownload

        case $genDownload in
            [Yy]* )
                echo -e "\nDownloading genomes...\n" 
                fastq_screen --get_genomes --outdir "res/fastq_screen_samples"
            ;;
            [Nn]* )
                echo -e "\nSkipping genome download...\n"
            ;;
        esac
```

para después correr la herramienta utilizando los parámetros **--conf  (apunta al fichero de configuración)**, **--tag (etiqueta las lecturas en función del indice con el que casen)**, -**-aligner (especifica el alineador a utilizar, el cual debe corresponderse con el usado para la generación de los índices; en el caso de los usados de serie por *fastqscreen*, bowtie2 )**, **--subset (tamaño de sampleo, para no usar todo el fastq)**,**--threads (numero de cores a utilizar)**, y **--outdir (indica el directorio de salida).**

```shell
fastq_screen --conf "$screen_gen/fastq_screen.conf" \
    --tag --aligner bowtie2 --subset 100000 --threads 14 \
    --outdir "$fastqscreen_dir/$cut_sid" $sid 2>&1 log/qc/fastqscreen.log) & spinner $!
```

#### OPT 2: Menú de Opciones y elección de workflow `pipeline.sh`

Tanto como si se ha decidido no realizar un control de calidad de las muestras como si se ha hecho, el siguiente paso consiste en el procesamiento de la muestra a través de numeras opciones de workflow en función de los intereses del investigador, a través de un menú interactivo.

Éste se encuentra dividido en dos categorías; por una parte, workflows sin preprocesamiento para alineamiento rápido en muestras de muy alta calidad; y por otra, diferentes workflows que incluyen pre-procesado previo de las mismas.

```shell
# Different pipelines for different workflows
echo -e "${GREEN}\nWORKFLOW PIPELINE MENU\n${NC}
${RED}Default cores set to 14, change accordingly\n${NC}"

echo -e "
${YELLOW}BASIC WORKFLOWS FOR HIGH QUALITY READS, NO PRE-PROCESSING\n${NC}
\tWORKFLOW 1 (Using STAR aligner)\n
\tWORKFLOW 2 (Using HISAT2 aligner)\n
\tWORKFLOW 3 (Using SALMON pseudo-aligner)\n
\tWORKFLOW 4 (Using KALLISTO pseudo-aligner)\n
${YELLOW}ADVANCED WORKFLOWS INCLUDING PREPROCESSING\n${NC}
\tWORKFLOW 5 (Toolset: FastQScreen, Cutadapt, STAR)\n
\tWORKFLOW 6 (Toolset: FastQScreen, Cutadapt, HISAT2)\n
\tWORKFLOW 7 (Toolset: FastQScreen, Cutadapt, SALMON)\n
\tWORKFLOW 8 (Toolset: FastQScreen, Cutadapt, KALLISTO)\n
\tWORKFLOW 9 (Toolset: FastQScreen, Fastp, STAR)\n
\tWORKFLOW 10 (Toolset: FastQScreen, Fastp, HISAT2)\n
\tWORKFLOW 11 (Toolset: FastQScreen, Fastp, SALMON)\n
\tWORKFLOW 12 (Toolset: FastQScreen, Fastp, KALLISTO)\n"

read -rp "Option: " menuOp
```

##### Herramientas de pre-procesamiento

###### Cutadapt

Cutadapt es una herramienta que permite el cribado de las lecturas por calidad, así como la remoción de adaptadores usados en la secuenciación. Debido al tipo de experimento realizado, se utilizó con los siguientes parámetros (los cuales deben ser modificados acordes al experimento a analizar):

- **-a, -A, -g y -G** representan respectivamente adaptadores hallados en los extremos 5' y 3' de las muestras forward (minúscula) y reverse (mayúscula). Se eliminaron los diferentes adaptadores encontrados en el análisis FasQC + típicos en secuenciación Illumina PE (enlaces), así como residuos PolyA y PolyG.
- **-q** es el umbral de calidad que debe superar una lectura para ser considerada válida. Se fijó en 15 por concordancia con el umbral por defecto de FastP.
- **-o**  y **-p** son las rutas de salida del fichero procesado, seguidas en este caso de los ficheros a procesar (f_path y r_path).
- **--cores** fija el número de nucleos
- **-m** fija la longitud mínima que debe tener una lectura para ser considerada válida. Se fijó en 15 por concordancia con el umbral por defecto de FastP.
- **--discard-untrimmed** toma como válidas solo aquellas lecturas que hayan sido preprocesadas.

```shell
cutadapt -a AGATCGGAAGAGCACACGTCTGAACTCCAGTCA -A AGATCGGAAGAGCGTCGTGTAGGGAAAGAGTGT \
            -a CTGTCTCTTATACACATCT -A CTGTCTCTTATACACATCT \
            -g TCGTCGGCAGCGTCAGATGTGTATAAGAGACAG -G GTCTCGTGGGCTCGGAGATGTGTATAAGAGACAG \
            -a CTGTCTCTTATACACATCT...AGATGTGTATAAGAGACAG -a TGGAATTCTCGGGTGCCAAGG \
            -a "G{10}" -A "G{10}" -g "G{10}" -G "G{10}" -g "A{10}" -G "A{10}" -q 15 \
            -o "$outdir/${f_sid}_trimmed.fastq" -p "$outdir/${r_sid}_trimmed.fastq" \
            "$f_path" "$r_path" --cores 14 -m 15 --discard-untrimmed > "$logdir"/log.txt
```

Tras esto, se le da la posibilidad al usuario de realizar un nuevo control de calidad de las muestras procesadas.

```shell
# Re-run quality control
    read -rp "Would you like to re-run QC report for your trimmed samples? (Y/n) " runqc

    for trimmed_sid in $(find $outdir -type f -name "*_trimmed.fastq");do
        case $runqc in
            [Yy]* )
                bash scripts/qc.sh $trimmed_sid "out/qc/fastqc" "out/qc/fastq_screen"
            ;;
        esac
    done

    case $runqc in
    [Yy]* )
        printf "${GREEN}\nNow, take your time to give a look to the QC analysis.\n${NC}"
        echo "When you are ready, press any key to continue..."
        read -n 1 -s -r -p ""
    ;;
    esac
```

###### FastP

Herramienta de control de calidad y preprocesado muy completa, que permite automatizar la eliminación de adaptadores y cribado de las lecturas sin necesidad de hardcodear las secuencias. Se usó con los siguientes parámetros:

- **-i, -o, -I** y **-O** representan los ficheros de entrada (i) y salida (o), para las lecturas forward (minúscula) y reverse (mayúscula).
- **--detect_adapter_for_pe** detecta automáticamente adaptadores usados en PE.
- **5** y **3** realizan los cortes en ambos extremos de la lectura, en función de si las bases en estas superan un umbral de calidad determinado.
- **-D** realiza deduplicación de las muestras.
- **--dup_calc_accuracy** fijado en 3 como calidad por defecto en deduplicación.
- **-c** corrige errores de solapamiento en muestras PE.
- **-p** realiza un análisis de secuencias sobrerrepresentadas.
- **-h** exporta los resultados en formato HTML para mejor visualización que en JSON por defecto.
- **-w** fija el número de cores a utilizar.

```shell
fastp -i $f_path -o "$outdir/${f_sid}_trimmed.fastq" -I $r_path -O "$outdir/${r_sid}_trimmed.fastq" \
 --detect_adapter_for_pe -5 -3 -D --dup_calc_accuracy 3 -c -p -P 20 \
 -h "$outdir/${base_sid}.html" -w 14 > "$logdir"/log.txt
```

##### Herramientas de indexado y alineamiento

Para ver una descripción detallada de las diferencias entre las distintas herramientas de alineamiento, echar un vistazo al manual incluído con las mismas.

Uso independeinte del script de indexado

```shell
# Comprobation for independent use of script
if [ "$#" -ne 1 ]
then
    printf "${RED}Usage: $1 <tool> ${NC}\n"
    echo -e 'tool: "STAR", "HISAT2", "SALMON", "KALLISTO"\n'
    exit 1
fi
```

y de alineamiento:

```shell
# Comprobation for independent use of script
if [ "$#" -ne 6 ]
then
    printf "${RED}Usage: $1 <tool> $2 <f_path> $3 <r_path> $4 <outdir> $5 <logdir> $6 <workflow>${NC}\n"
    echo -e 'tool: "STAR", "HISAT2", "SALMON", "KALLISTO"
workflow: "untrimmed", "cutadapt", "fastp"\n'
    exit 1
fi
```

###### STAR

Parámetros utilizados para el indexado de las muestras:

- El único parámetro a remarcar es **-genomeSAindex**, el cual fue fijado a partir de las recomendaciones dadas por la propia herramienta en su primera ejecución. Modificar acorde a las condiciones del experimento.

```shell
STAR     --runThreadN 14 --runMode genomeGenerate --genomeDir $outdir \
                --genomeFastaFiles $ref_gen --runRNGseed 1998 --genomeSAindexNbases 11 > $logdir/$tool.log
```

Parámetros utilizados para el alineamiento:

A remarcar el parámetro **--outSAMtype** fijado en sorted BAM que nos permite ahorrarnos pasos en la conversión del SAM al BAM. Ejecución posterior de *samtools* para generar index del fichero de alineamiento y diferentes estadísticas del mismo (generadas con *samtools* y *bamCoverage*).

```shell
STAR --runThreadN 14 --readFilesIn "$f_path" $r_path  \
            --genomeDir "$index_dir" --outReadsUnmapped Fastx  \
            --outFileNamePrefix "$outdir/" \
            --outSAMtype BAM SortedByCoordinate

# add more params for statistics (there's a few problems here to solve)
bam_file=$(find "$outdir" -type f -name "*.bam")
(samtools stats "$bam_file" > "$bam_file".txt) & spinner $!
(samtools index "$bam_file") & spinner $!
(bamCoverage -b "$bam_file" -o "$outdir/$base_sid.bw" --normalizeUsing BPM) & spinner $!
```

###### HISAT2

Ningún parámetro a recalcar en la generación del índice:

```shell
hisat2-build -p 14 --seed 1998 $ref_gen $outdir/HISAT2
```

El alineamiento de la muestra requiere de un mayor número de pasos al utilizar *hisat2* en su conversión a BAM.

```shell
(hisat2 --new-summary --summary-file "$outdir/$base_sid.hisat2.summary" \
    -p 14 -x "$index_dir/HISAT2" -1 "$f_path" -2 "$r_path" -k 1 -S "$outdir/$base_sid.sam") & spinner $!

# problema con el pipe
# add more params for statistics
(samtools view -bS "$outdir/$base_sid.sam" > "$outdir/$base_sid.bam") & spinner $!
(samtools stats "$outdir/$base_sid.bam" > "$outdir/$base_sid.txt") & spinner $!
(samtools sort --write-index "$outdir/$base_sid.bam" -o "$outdir/$base_sid.sorted.bam") & spinner $!
(samtools stats "$outdir/$base_sid.sorted.bam" > "$outdir/$base_sid.sorted.txt") & spinner $!
(bamCoverage -b "$outdir/$base_sid.sorted.bam" -o "$outdir/$base_sid.bw" --normalizeUsing BPM) & spinner $!
```

###### SALMON

Tanto *SALMON* como *KALLISTO* son pseudoalineadores que trabajan de una manera diferente a los dos previamente descritos.

Generación del índice (utilizando exoma de referencia en vez de genoma de referencia):

```shell
salmon index -t $ref_cdna -i $outdir --gencode -p 14 > $logdir/$tool.log
```

Alineamiento de las muestras:

- **-l** es el tipo de stranding de la muestra. Fijado en A para determinación automática.
- **-1 y -2** son los ficheros de entrada.
- **-g** da la opción de añadir fichero de anotación.
- **--writeMappings** escribe los alineamientos en formato SAM.

```shell
salmon quant -i "$index_dir" -l A -1 "$f_path" -2 "$r_path" --validateMappings \
    -o "$outdir" -g "$ref_gtf" -p 14 --writeMappings 
```

###### KALLISTO

Generación de índice:

```shell
kallisto index -i $outdir/${base_ref_cdna}.idx $ref_cdna > $logdir/$tool.log
```

Pseudoalineamiento:

- **--bias** trata de corrigir errores de sesgo.
- **--fusion** busca fusiones en Pizzly.
- **--pseudobam** escribe los pseudoalinamientos con el transcriptoma  a un fichero con formato BAM.
- **--genomebam** projecta los pseudoalineamientos frente al exoma de referencia.
- **--gtf** permite la inserción de anotaciones en formato GTF.

```shell
kallisto quant -i "$index_dir/$base_ref_cdna.idx" --bias --fusion \
    "$f_path" "$r_path" -o "$outdir" --pseudobam --genomebam \
    --gtf "$ref_gtf" -t 14

    pseudobam="$outdir/pseudoalignments.bam"
    bamCoverage -b "$pseudobam" -o "$outdir/$base_sid.pseudoalignments.bw" \
    --normalizeUsing BPM 2>&1
```

#### Post-procesado y conteo de muestras (read summarization programs)

Uso independiente del script:

```shell
if [ "$#" -ne 3 ]
then
    printf "${RED}Usage: $1 <tool> $2 <bam_file> $3 <counts_out_dir>${NC}\n"
    echo -e 'tool: "featurecounts", "htseq"\n'
    exit 1
fi
```

###### FEATURECOUNTS

```shell
featureCounts -T 14 -s 2 -p --countReadPairs -a "$ref_gtf" -t exon -g gene_id \
    -o "$countdir/counts.txt" "$bam"
```

###### HTSEQ

```shell
htseq-count --format=bam --mode=intersection-nonempty --minaqual=10 --type=exon --idattr=gene_id    \
    --additional-attr=gene_name "$bam" "$ref_gtf" > "$countdir/$base_bam.htseq"
```

## 

## ANÁLISIS DE RESULTADOS

#### 1ER CONTROL DE CALIDAD CON FASTQC Y FASTQSCREEN

- Muestra 1_1 y 1_2 (SRR479052)
  
  Diferencias mínimas entre ambas.
  
  **FASTQC**

![](/home/miguel/.var/app/com.github.marktext.marktext/config/marktext/images/2023-04-15-17-59-37-image.png)Clara deficiencia de calidad en las lecturas debido a una alta degradación de rendimiento al final de la secuenciación.

![](/home/miguel/.var/app/com.github.marktext.marktext/config/marktext/images/2023-04-15-13-10-14-image.png)

![](/home/miguel/.var/app/com.github.marktext.marktext/config/marktext/images/2023-04-15-13-10-33-image.png)

Presencia de lecturas duplicadas y adaptadores que deben ser eliminados.

**FASTQSCREEN**

![](/home/miguel/.var/app/com.github.marktext.marktext/config/marktext/images/2023-04-15-13-28-37-SRR479052_1_screen.png)

Presencia de diferentes genomas contaminantes, vectores, mDNA, adaptadores, etc.

- Muestras 2_1 y 2_2 (SRR479054)
  
  Misma consideración respecto a las diferencias entre ambas
  
  **FASTQC**

![](/home/miguel/.var/app/com.github.marktext.marktext/config/marktext/images/2023-04-15-18-00-07-image.png)Clara deficiencia de calidad en las lecturas debido a una alta degradación de rendimiento al final de la secuenciación.

![](/home/miguel/.var/app/com.github.marktext.marktext/config/marktext/images/2023-04-15-13-40-21-image.png)

Presencia de lecturas duplicadas y adaptadores que deben ser eliminados.

![](/home/miguel/.var/app/com.github.marktext.marktext/config/marktext/images/2023-04-15-13-40-30-image.png)

Presencia de lecturas duplicadas y adaptadores que deben ser eliminados.

**FASTQSCREEN**

![](/home/miguel/.var/app/com.github.marktext.marktext/config/marktext/images/2023-04-15-13-41-38-SRR479054_1_screen.png)

Presencia de diferentes genomas contaminantes, vectores, mDNA, adaptadores, etc.

#### ESTADISTICAS DE ALINEAMIENTO SIN PREPROCESADO

Se procede a presentar los resultados de un alineador y un pseudoalineador por comparación.

##### HISAT2

**Muestra SRR479052**

<u>HISAT2 summary stats:</u>

    Total pairs: 12647534
        Aligned concordantly or discordantly 0 time: 12431709 (98.29%)
        Aligned concordantly 1 time: 211024 (1.67%)
        Aligned concordantly >1 times: 0 (0.00%)
        Aligned discordantly 1 time: 4801 (0.04%)
    Total unpaired reads: 24863418
        Aligned 0 time: 24817231 (99.81%)
        Aligned 1 time: 46187 (0.19%)
        Aligned >1 times: 0 (0.00%)
    Overall alignment rate: 1.89%

*Ver gráficas de *plot-bamstats* para más información.*

<u>*FeatureCounts summary stats:*</u>

Status    out/aligned/hisat2/SRR479052/20230415141956/SRR479052.sorted.bam
Assigned    62629
Unassigned_Unmapped    12388267
Unassigned_Read_Type    0
Unassigned_Singleton    0
Unassigned_MappingQuality    0
Unassigned_Chimera    0
Unassigned_FragmentLength    0
Unassigned_Duplicate    0
Unassigned_MultiMapping    0
Unassigned_Secondary    0
Unassigned_NonSplit    0
Unassigned_NoFeatures    188257
Unassigned_Overlapping_Length    0
Unassigned_Ambiguity    8381

<u>*HTSEQ stats:*</u>

Warning: 433876 reads with missing mate encountered.
12872221 alignment record pairs processed.



**Muestra SRR479054**

<u>*HISAT2 summary stats:*</u>
    Total pairs: 8096699
        Aligned concordantly or discordantly 0 time: 7980123 (98.56%)
        Aligned concordantly 1 time: 114532 (1.41%)
        Aligned concordantly >1 times: 0 (0.00%)
        Aligned discordantly 1 time: 2044 (0.03%)
    Total unpaired reads: 15960246
        Aligned 0 time: 15934432 (99.84%)
        Aligned 1 time: 25814 (0.16%)
        Aligned >1 times: 0 (0.00%)
    Overall alignment rate: 1.60%

*Ver gráficas de *plot-bamstats* para más información.*

<u>*FeatureCounts summary stats:*</u>

Status    out/aligned/hisat2/SRR479054/20230415141956/SRR479054.sorted.bam
Assigned    35982
Unassigned_Unmapped    7955760
Unassigned_Read_Type    0
Unassigned_Singleton    0
Unassigned_MappingQuality    0
Unassigned_Chimera    0
Unassigned_FragmentLength    0
Unassigned_Duplicate    0
Unassigned_MultiMapping    0
Unassigned_Secondary    0
Unassigned_NonSplit    0
Unassigned_NoFeatures    100736
Unassigned_Overlapping_Length    0
Unassigned_Ambiguity    4221

<u><em>HTSEQ stats:</em></u>

Warning: 23075 reads with missing mate encountered.
987045 alignment record pairs processed.

##### SALMON

**Muestra SRR479052**

{
    "read_files": "[ res/samples/dumped_fastq/SRR479052/SRR479052_1.fastq, res/samples/dumped_fastq/SRR479052/SRR479052_2.fastq]",
    "expected_format": "IU",
    "compatible_fragment_ratio": 1.0,
    "num_compatible_fragments": 10656220,
    "num_assigned_fragments": 10656220,
    "num_frags_with_concordant_consistent_mappings": 8995116,
    "num_frags_with_inconsistent_or_orphan_mappings": 1789907,
    "strand_mapping_bias": 0.4986155820558623,
    "MSF": 0,
    "OSF": 0,
    "ISF": 4485105,
    "MSR": 0,
    "OSR": 0,
    "ISR": 4510011,
    "SF": 930565,
    "SR": 859342,
    "MU": 0,
    "OU": 0,
    "IU": 0,
    "U": 0
}

**Muestra SRR479054**

{
    "read_files": "[ res/samples/dumped_fastq/SRR479054/SRR479054_1.fastq, res/samples/dumped_fastq/SRR479054/SRR479054_2.fastq]",
    "expected_format": "IU",
    "compatible_fragment_ratio": 1.0,
    "num_compatible_fragments": 5986505,
    "num_assigned_fragments": 5986505,
    "num_frags_with_concordant_consistent_mappings": 5204445,
    "num_frags_with_inconsistent_or_orphan_mappings": 850373,
    "strand_mapping_bias": 0.4990628203391524,
    "MSF": 0,
    "OSF": 0,
    "ISF": 2597345,
    "MSR": 0,
    "OSR": 0,
    "ISR": 2607100,
    "SF": 434108,
    "SR": 416265,
    "MU": 0,
    "OU": 0,
    "IU": 0,
    "U": 0
}



#### ESTADISTICAS DE ALINEAMIENTO CON PREPROCESADO

##### Cutadapt

**Muestra SRR479052**

![](/home/miguel/.var/app/com.github.marktext.marktext/config/marktext/images/2023-04-15-17-59-05-image.png)

![](/home/miguel/.var/app/com.github.marktext.marktext/config/marktext/images/2023-04-15-17-58-32-image.png)

![](/home/miguel/.var/app/com.github.marktext.marktext/config/marktext/images/2023-04-15-18-01-02-SRR479052_1_trimmed_screen.png)

Corrección de deficit de calidad por cribado, y eliminación de porciones sobrerrepresentadas y adaptadores.

**Muestra SRR479054**

![](/home/miguel/.var/app/com.github.marktext.marktext/config/marktext/images/2023-04-15-18-02-01-image.png)

![](/home/miguel/.var/app/com.github.marktext.marktext/config/marktext/images/2023-04-15-18-02-31-image.png)

![](/home/miguel/.var/app/com.github.marktext.marktext/config/marktext/images/2023-04-15-18-02-47-image.png)

![](/home/miguel/.var/app/com.github.marktext.marktext/config/marktext/images/2023-04-15-18-01-27-SRR479054_1_trimmed_screen.png)

Corrección de deficit de calidad por cribado, y eliminación de porciones sobrerrepresentadas y adaptadores. Presencia de una secuencia sobrerrepresentada desconocida. Tras BLASTear esta secuencia, se asume como contaminación mitocondrial que debería ser eliminada.

![](/home/miguel/.var/app/com.github.marktext.marktext/config/marktext/images/2023-04-15-18-04-37-image.png)

###### HISAT2

**Muestra SRR479052**

*<u>HISAT2 summary stats:</u>*    

Total pairs: 2180086
        Aligned concordantly or discordantly 0 time: 2132036 (97.80%)
        Aligned concordantly 1 time: 47424 (2.18%)
        Aligned concordantly >1 times: 0 (0.00%)
        Aligned discordantly 1 time: 626 (0.03%)
    Total unpaired reads: 4264072
        Aligned 0 time: 4257451 (99.84%)
        Aligned 1 time: 6621 (0.16%)
        Aligned >1 times: 0 (0.00%)
    Overall alignment rate: 2.36%

<u><em>FeatureCounts summary stats:</em></u>

Status    out/aligned/hisat2_cutadapt/SRR479052/20230415170851/SRR479052.sorted.bam
Assigned    11710
Unassigned_Unmapped    2125755
Unassigned_Read_Type    0
Unassigned_Singleton    0
Unassigned_MappingQuality    0
Unassigned_Chimera    0
Unassigned_FragmentLength    0
Unassigned_Duplicate    0
Unassigned_MultiMapping    0
Unassigned_Secondary    0
Unassigned_NonSplit    0
Unassigned_NoFeatures    40780
Unassigned_Overlapping_Length    0
Unassigned_Ambiguity    1841

**Muestra SRR479054**

*<u>HISAT2 summary stats:</u>*    

Total pairs: 975201        Aligned concordantly or discordantly 0 time: 956617 (98.09%)
        Aligned concordantly 1 time: 18333 (1.88%)
        Aligned concordantly >1 times: 0 (0.00%)
        Aligned discordantly 1 time: 251 (0.03%)
    Total unpaired reads: 1913234
        Aligned 0 time: 1909733 (99.82%)
        Aligned 1 time: 3501 (0.18%)
        Aligned >1 times: 0 (0.00%)
    Overall alignment rate: 2.09%

<u><em>FeatureCounts summary stats:</em></u>

Status    /opt/temp_bioinfo/transcriptomic-final-exercise/out/aligned/hisat2_cutadapt/SRR479054/20230415170851/SRR479054.sorted.bam
Assigned    4841
Unassigned_Unmapped    953267
Unassigned_Read_Type    0
Unassigned_Singleton    0
Unassigned_MappingQuality    0
Unassigned_Chimera    0
Unassigned_FragmentLength    0
Unassigned_Duplicate    0
Unassigned_MultiMapping    0
Unassigned_Secondary    0
Unassigned_NonSplit    0
Unassigned_NoFeatures    16417
Unassigned_Overlapping_Length    0
Unassigned_Ambiguity    676

###### SALMON

**Muestra SRR479052**

{
    "read_files": "[ out/trimmed/cutadapt/SRR479052/SRR479052_1_trimmed.fastq, out/trimmed/cutadapt/SRR479052/SRR479052_2_trimmed.fastq]",
    "expected_format": "IU",
    "compatible_fragment_ratio": 1.0,
    "num_compatible_fragments": 1973597,
    "num_assigned_fragments": 1973597,
    "num_frags_with_concordant_consistent_mappings": 1913317,
    "num_frags_with_inconsistent_or_orphan_mappings": 81890,
    "strand_mapping_bias": 0.49651782741699365,
    "MSF": 0,
    "OSF": 0,
    "ISF": 949996,
    "MSR": 0,
    "OSR": 0,
    "ISR": 963321,
    "SF": 32170,
    "SR": 49720,
    "MU": 0,
    "OU": 0,
    "IU": 0,
    "U": 0
}

**Muestra SRR479054**

{
    "read_files": "[ out/trimmed/cutadapt/SRR479054/SRR479054_1_trimmed.fastq, out/trimmed/cutadapt/SRR479054/SRR479054_2_trimmed.fastq]",
    "expected_format": "IU",
    "compatible_fragment_ratio": 1.0,
    "num_compatible_fragments": 840148,
    "num_assigned_fragments": 840148,
    "num_frags_with_concordant_consistent_mappings": 805230,
    "num_frags_with_inconsistent_or_orphan_mappings": 43832,
    "strand_mapping_bias": 0.49611912124486176,
    "MSF": 0,
    "OSF": 0,
    "ISF": 399490,
    "MSR": 0,
    "OSR": 0,
    "ISR": 405740,
    "SF": 16826,
    "SR": 27006,
    "MU": 0,
    "OU": 0,
    "IU": 0,
    "U": 0
}

##### FASTP

Ambos informes se incluyen junto con este para su visualización, ya que contienen mucha más información que los de FASTQ.

**Muestra SRR479052**

![](/home/miguel/.var/app/com.github.marktext.marktext/config/marktext/images/2023-04-15-18-27-10-image.png)

**Muestra SRR479054**

![](/home/miguel/.var/app/com.github.marktext.marktext/config/marktext/images/2023-04-15-18-18-35-image.png)

##### 

Los alineamientos e indices se generan de la misma manera que la anterior. A pesar de que los resultados tras procesar las lecturas son distintos, se decide obviarlos de cara al informe ya que se sale de lo que se está pidiendo. 
